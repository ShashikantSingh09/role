# GuardDuty via Terraform
## Project Overview

This project automates the deployment and management of [AWS GuardDuty](https://aws.amazon.com/guardduty/) across multiple AWS regions using [Terraform](https://www.terraform.io/). It provides a scalable and consistent way to enable GuardDuty detectors and features in all regions required by your organization, ensuring comprehensive threat detection coverage.

This codebase is intended to be run primarily from GitHub Actions (GHA) using OIDC and an assume-role for credentials. Local execution remains supported for development and troubleshooting.

## Key Features

- **Multi-Region Support:** Easily enable and configure GuardDuty in any AWS region by updating a single list variable.
- **Modular Design:** Uses Terraform modules to encapsulate GuardDuty configuration, making it easy to add, remove, or update regions.
- **Feature Customization:** Supports enabling or disabling specific GuardDuty features (such as S3 protection, EKS audit logs, EBS malware protection, etc.) per region.

  - Use `detector_feature_status` and `detector_runtime_additional_status` module variables to control which features are enabled on the management (administrator) GuardDuty detector.
  - Use `feature_auto_enable` to manage the auto-enablement policy (NONE/NEW/ALL) for member accounts in the AWS Organization.
- **Organization Integration:** Can be configured to manage GuardDuty at the AWS Organization level, including auto-enabling for new accounts.
- **Member Account Feature Exceptions:** Allows specific member accounts to override organization-wide GuardDuty feature settings (e.g., disabling S3 protection for specific accounts while keeping it enabled organization-wide).
- **External Detector ID Lookup:** Uses a helper script to dynamically fetch existing GuardDuty detector IDs, supporting both new and pre-existing environments.

## How It Works

- The list of AWS regions to manage is defined in `variables.tf`.
- For each region, a dedicated Terraform module is instantiated, which provisions the GuardDuty detector and configures its features.
- Provider blocks are aliased for each region to ensure resources are created in the correct AWS region.
- The project supports both standalone and organization-wide GuardDuty deployments.
- Member account feature exceptions (like disabling S3_DATA_EVENTS for specific accounts) are managed using `aws_guardduty_member_detector_feature` resources that override the organization-level auto-enable policy for specific accounts across all enabled regions.
- Helper scripts (such as `get_gd_detector_id.sh`) are used to fetch existing detector IDs, allowing for seamless import or management of existing GuardDuty resources.

This approach ensures that your AWS environment is protected by GuardDuty everywhere you need it, with minimal manual effort and maximum consistency.

## CI/CD (GitHub Actions)

The recommended way to run this Terraform is via GitHub Actions using OIDC to assume an AWS IAM role.

- Ensure your repository has an IAM Role in the target AWS account that trusts GitHub OIDC and grants the necessary permissions (S3 backend access and GuardDuty management).
- Configure the workflow to export AWS credentials via `aws-actions/configure-aws-credentials` or your preferred mechanism.
<!--- - Run `terraform init -reconfigure -backend-config="backend-config.conf"` so state is stored in the S3 bucket noted below. -->

Example workflow excerpt (simplified and aligned with this repo's workflow):

```yaml
name: Terraform GuardDuty
on:
  pull_request:
    paths:
      - 'multi-account/guardduty-terraform/guardduty-terraform-codebase/**'
  push:
    branches: [ master ]
    paths:
      - 'multi-account/guardduty-terraform/guardduty-terraform-codebase/**'

permissions:
  id-token: write
  contents: read

jobs:
  plan:
    if: github.event_name == 'pull_request'
    runs-on: [ self-hosted, jamf-ubuntu-latest ]
    defaults:
      run:
        working-directory: multi-account/guardduty-terraform/guardduty-terraform-codebase
    steps:
      - uses: actions/checkout@v4
      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: 1.13.0
      - name: Configure AWS credentials (OIDC)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_ROLE_FOR_GUARDDUTY_TERRAFORM }}
          aws-region: us-east-1
      - run: terraform fmt -check -recursive
      - run: terraform init -input=false
      - run: terraform validate -no-color
      - run: terraform plan -input=false -no-color -out=tfplan.binary

  apply:
    if: github.event_name == 'push' && github.ref == 'refs/heads/master'
    runs-on: [ self-hosted, jamf-ubuntu-latest ]
    defaults:
      run:
        working-directory: multi-account/guardduty-terraform/guardduty-terraform-codebase
    steps:
      - uses: actions/checkout@v4
      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: 1.13.0
      - name: Configure AWS credentials (OIDC)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_ROLE_FOR_GUARDDUTY_TERRAFORM }}
          aws-region: us-east-1
      - run: terraform init -input=false
      - run: terraform apply -input=false -auto-approve
```

Notes:
- Providers in this repo rely on ambient AWS credentials (no `profile` in provider blocks). In GHA, credentials come from the OIDC-assumed role.
- In GHA we do not pass `-backend-config`; the backend is defined in `backend.tf` and authentication uses OIDC. The `backend-config.conf` file is intended for local runs only.

## Backend
- Current state is stored in S3 bucket `secops-terraform-state-guardduty-management-itqthehw` which is located in `SecOps-Prod (#782439390712)` account, region `us-east-2`.
- The S3 bucket is used for state locking as well.

### Prerequisites (local)

- [Terraform](https://www.terraform.io/downloads.html) installed.
- AWS CLI installed and configured with appropriate credentials.
- An AWS account with permissions to manage GuardDuty and Organizations (if using org-wide features).

## Configuration Variables

This project uses several key variables to customize behavior:

### Core Variables
- **`aws_regions`**: List of AWS regions where GuardDuty will be enabled (defined in `variables.tf`)
- **`gd_finding_publishing_frequency`**: How frequently updated findings are exported (default: `FIFTEEN_MINUTES`)
- **`auto_enable_organization_members`**: Auto-enable policy for member accounts (`NONE`, `NEW`, or `ALL`)

### Member Account Feature Variables
- **`dataops_member_account_id`**: Account ID for jamf-dataops-prod that has an S3 protection exception (default: `533454354590`)
- **`s3_data_events_feature_status`**: Status override for S3_DATA_EVENTS feature for the jamf-dataops-prod account (default: `DISABLED`)

### Local Variables
- **`protection_plan_auto_enable_AllTheWay_ExceptRuntimeMonitoring`**: Unified protection plan configuration that enables all features except runtime monitoring (defined in `locals` block in `main.tf`)

### External Data Sources
- **`guardduty_detector_id`**: Dynamically fetches the delegated admin account's GuardDuty detector IDs for all enabled regions using the `get_gd_detector_id.sh` script. This is used when configuring member account feature exceptions.

### How to Add a New Region

Follow these steps to add GuardDuty support for a new AWS region:

1. **Add a Provider Block**
   - Open `providers.tf`.
   - Add a new provider block for the desired region. For example:
    ```hcl
    provider "aws" {
      alias  = "eu_central_2"
      region = "eu-central-2"
    }
    ```

2. **Update the Regions List**
   - Open `variables.tf` in the root directory.
   - Add the new region (e.g., `"eu-central-2"`) to the `aws_regions` list variable.

3. **Create a Module Block**
   - Open `main.tf` in the root directory.
   - Add a new module block for the region, referencing the correct provider. For example:
     ```hcl
     module "guardduty_eu_central_2" {
       count    = contains(var.aws_regions, "eu-central-2") ? 1 : 0
       source   = "./modules/guardduty"
       providers = { aws = aws.eu_central_2 }
       finding_publishing_frequency     = var.gd_finding_publishing_frequency
       auto_enable_organization_members = var.auto_enable_organization_members
       feature_auto_enable              = local.protection_plan_auto_enable_S3new_EKSnew_RuntimeNone_EKSaddonNone_EBSnew_RDSnone_Lambdanone
     }
     ```

4. **Add Import Blocks (if importing existing resources)**
   - Open `imports.tf` in the root directory.
   - Add import blocks for any existing GuardDuty resources in the new region, if needed.
   - The already imported resources are commented out in the `imports.tf`. Keeping it there for reference.

5. **Configure Feature Protection Plans**
   - In `main.tf`, select or create a local variable for the feature protection plan that matches your security requirements.
   - You can use one of the existing local variables (e.g., `local.protection_plan_auto_enable_S3new_EKSnew_...`) or define a new one.

### Managing Member Account Feature Exceptions

The project includes the ability to override specific GuardDuty features for individual member accounts across all regions. This is necessary when certain accounts require exceptions from the organization-wide auto-enable policy.

**Current Exception:**
- **jamf-dataops-prod account (`533454354590`)** requires S3_DATA_EVENTS protection to be **DISABLED** across all regions, despite the organization-wide policy enabling it for all other member accounts.
- This exception is implemented using the `aws_guardduty_member_detector_feature.dataops_account_s3_protection_plan` resource with `for_each` to apply the override in every enabled region.

**Why This Is Needed:**
When GuardDuty's organization-level auto-enable is configured (via `feature_auto_enable` in the module), it automatically applies protection plans to all member accounts. To disable a specific feature for a particular member account, you must explicitly create a member detector feature resource with `status = "DISABLED"`. This overrides the organization-level setting for that specific account and feature.

**Implementation Details:**
- The resource uses the `data.external.guardduty_detector_id` data source to dynamically fetch the **delegated admin account's detector IDs** for all enabled regions
- The detector IDs are retrieved via the `get_gd_detector_id.sh` script which queries the GuardDuty API for each region
- The `account_id` parameter specifies which member account to configure (in this case, `533454354590`)
- The feature status (`DISABLED`) is controlled via the `var.s3_data_events_feature_status` variable for easier management

**Important:** The `detector_id` parameter must use the **delegated admin account's** detector ID (not the member account's detector ID). The external data source handles this automatically by running in the context of the delegated admin account.

**To Add Similar Exceptions for Other Accounts:**

Simply create a new resource with the appropriate account ID, feature name, and status:

```hcl
resource "aws_guardduty_member_detector_feature" "another_account_exception" {
  for_each    = data.external.guardduty_detector_id
  detector_id = each.value.result.id
  account_id  = "account-id-here"
  name        = "S3_DATA_EVENTS"  # or other feature name
  status      = "DISABLED"        # or "ENABLED"
}
```

No additional detector ID maps are needed—the external data source automatically provides the correct delegated admin detector IDs for all enabled regions.

### How to Apply the Changes (Local)
1. **Use AWS profile of your choice**
    ```
    export AWS_PROFILE=SecOps-Prod.AdministratorAccess
    ```

2. **Initialize Terraform**
   ```
   terraform init
   ```

3. **Review the Planned Changes**
   ```
   terraform plan
   ```

4. **Apply the Configuration**
   ```
   terraform apply
   ```

### Local Credentials and Profiles

Providers do not set `profile`; they use whichever credentials are available in your shell. Common options:

- Export environment variables: `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, and optionally `AWS_SESSION_TOKEN`.
- Or set a CLI profile for the current shell: `export AWS_PROFILE=SecOps-Prod.AdministratorAccess`.

### Additional Notes

- The `get_gd_detector_id.sh` script is used to dynamically fetch the delegated admin account's GuardDuty detector IDs for each region. This ensures member account feature exceptions always use the correct detector IDs.
- When managing member account feature exceptions, the detector IDs are automatically retrieved from the delegated admin account (the account running Terraform), not from the member accounts themselves.
- Adding a new region requires only updating `var.aws_regions` and the corresponding provider/module blocks. The external data source will automatically fetch the detector ID for the new region.
- Ensure the AWS credentials (OIDC in GHA or your local profile/env vars) have the necessary permissions for the target regions, including `guardduty:ListDetectors` for the delegated admin account.
- For more information on GuardDuty features and configuration, see the [AWS GuardDuty documentation](https://docs.aws.amazon.com/guardduty/latest/ug/what-is-guardduty.html).

If you have any questions or run into issues, please consult the project maintainers or ask in a Slack channel.

---
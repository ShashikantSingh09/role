#!/bin/bash
REGION=$1
DETECTOR_ID=$(aws guardduty list-detectors --region $REGION --query 'DetectorIds[0]' --output text)
echo "{\"id\": \"$DETECTOR_ID\"}"